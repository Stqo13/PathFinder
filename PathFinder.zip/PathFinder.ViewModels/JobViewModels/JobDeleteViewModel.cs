﻿namespace PathFinder.ViewModels.JobViewModels
{
    public class JobDeleteViewModel
    {
        public int Id { get; set; }

        public required string Title { get; set; }

        public required string PublishedBy { get; set; }
    }
}
