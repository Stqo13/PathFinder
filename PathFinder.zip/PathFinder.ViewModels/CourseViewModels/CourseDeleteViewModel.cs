﻿namespace PathFinder.ViewModels.CourseViewModels
{
    public class CourseDeleteViewModel
    {
        public int Id { get; set; }

        public required string Name { get; set; }

        public required string PublishedBy { get; set; }
    }
}
