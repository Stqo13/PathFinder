﻿namespace PathFinder.Data.Models.Enums
{
    public enum Mode
    {
        Онлайн = 0,
        Присъствено = 1
    }
}
