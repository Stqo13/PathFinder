﻿namespace PathFinder.Data.Models.Enums
{
    public enum RequestStatus
    {
        Accepted,
        Declined,
        Pending
    }
}
