﻿namespace PathFinder.Data.Models.Enums
{
    public enum JobType
    {
        Онлайн = 0,
        Присъствено = 1,
        Стаж = 2
    }
}
